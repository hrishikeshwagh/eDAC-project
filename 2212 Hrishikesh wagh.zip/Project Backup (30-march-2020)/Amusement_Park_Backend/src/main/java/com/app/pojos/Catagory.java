package com.app.pojos;

public enum Catagory 
{

	THEMEPARK , WATERPARK;
	
}
