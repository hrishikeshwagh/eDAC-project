import React, { Component } from 'react';
import { toast } from "react-toastify";
import modal from "react-modal"; 
import 'react-toastify/dist/ReactToastify.css';
toast.configure();
class UserNavComp extends Component {


    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default UserNavComp;
